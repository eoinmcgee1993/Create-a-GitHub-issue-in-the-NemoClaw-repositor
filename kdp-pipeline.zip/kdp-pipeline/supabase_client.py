"""
Supabase integration for the pipeline.
Logs each run, updates book status, and uploads finished PDFs to dr-kdp-assets storage.

Gracefully degrades if SUPABASE_URL is not set, the pipeline runs locally without it.
"""
import json
import logging
import mimetypes
import time
from pathlib import Path
from typing import Optional

import httpx

from config import SUPABASE_URL, SUPABASE_SERVICE_KEY, BOOK

log = logging.getLogger("supabase")


def _enabled() -> bool:
    return bool(SUPABASE_URL and SUPABASE_SERVICE_KEY)


def _headers(json_body: bool = True) -> dict:
    h = {
        "apikey": SUPABASE_SERVICE_KEY,
        "Authorization": f"Bearer {SUPABASE_SERVICE_KEY}",
    }
    if json_body:
        h["Content-Type"] = "application/json"
    return h


# ---------- Book status ----------
def get_or_create_book(slug: Optional[str] = None) -> Optional[str]:
    """Find book row by slug, create if missing. Returns book.id."""
    if not _enabled():
        return None
    slug = slug or BOOK["slug"]
    url = f"{SUPABASE_URL}/rest/v1/dr_kdp_books?slug=eq.{slug}&select=id"
    r = httpx.get(url, headers=_headers(False), timeout=30)
    r.raise_for_status()
    rows = r.json()
    if rows:
        return rows[0]["id"]

    # Create
    payload = {
        "slug": BOOK["slug"],
        "series": BOOK["series"],
        "volume": BOOK["volume"],
        "title": BOOK["title"],
        "subtitle": BOOK["subtitle"],
        "list_price_usd": BOOK["list_price_usd"],
        "page_count": BOOK["page_count_target"],
        "design_count": BOOK["design_count"],
        "status": "queued",
    }
    r = httpx.post(
        f"{SUPABASE_URL}/rest/v1/dr_kdp_books",
        headers={**_headers(), "Prefer": "return=representation"},
        json=payload,
        timeout=30,
    )
    r.raise_for_status()
    return r.json()[0]["id"]


def update_book_status(book_id: str, status: str, extra: Optional[dict] = None):
    if not _enabled() or not book_id:
        return
    payload = {"status": status, "updated_at": "now()"}
    if extra:
        payload.update(extra)
    r = httpx.patch(
        f"{SUPABASE_URL}/rest/v1/dr_kdp_books?id=eq.{book_id}",
        headers=_headers(),
        json=payload,
        timeout=30,
    )
    r.raise_for_status()
    log.info(f"book status -> {status}")


# ---------- Run tracking ----------
def log_run(
    book_id: Optional[str],
    stage: str,
    status: str,
    duration_seconds: int = 0,
    cost_usd: float = 0.0,
    provider: Optional[str] = None,
    notes: Optional[dict] = None,
    github_run_id: Optional[str] = None,
):
    if not _enabled():
        return
    payload = {
        "book_id": book_id,
        "stage": stage,
        "status": status,
        "duration_seconds": duration_seconds,
        "cost_usd": cost_usd,
        "provider": provider,
        "notes": notes or {},
        "github_run_id": github_run_id,
    }
    try:
        r = httpx.post(
            f"{SUPABASE_URL}/rest/v1/dr_kdp_pipeline_runs",
            headers=_headers(),
            json=payload,
            timeout=30,
        )
        r.raise_for_status()
    except Exception as exc:
        log.warning(f"log_run failed: {exc}")


# ---------- Design tracking ----------
def upsert_designs(book_id: str, prompts_manifest: dict):
    if not _enabled() or not book_id:
        return
    rows = []
    for p in prompts_manifest["prompts"]:
        rows.append({
            "book_id": book_id,
            "design_index": p["index"],
            "pillar": p["pillar"],
            "subject": p["subject"],
            "prompt": p["prompt"],
            "status": p.get("status", "pending"),
        })
    r = httpx.post(
        f"{SUPABASE_URL}/rest/v1/dr_kdp_designs",
        headers={**_headers(), "Prefer": "resolution=merge-duplicates"},
        json=rows,
        timeout=60,
    )
    if r.status_code >= 400:
        log.warning(f"upsert_designs returned {r.status_code}: {r.text[:200]}")


# ---------- Storage uploads ----------
def upload_to_storage(local_path: Path, storage_path: str) -> Optional[str]:
    """Upload a file to dr-kdp-assets bucket. Returns the storage path on success."""
    if not _enabled():
        return None
    mime, _ = mimetypes.guess_type(str(local_path))
    mime = mime or "application/octet-stream"
    with local_path.open("rb") as f:
        data = f.read()
    url = f"{SUPABASE_URL}/storage/v1/object/dr-kdp-assets/{storage_path}"
    headers = {
        **_headers(False),
        "Content-Type": mime,
        "x-upsert": "true",
    }
    r = httpx.post(url, headers=headers, content=data, timeout=120)
    if r.status_code >= 400:
        log.warning(f"upload failed for {storage_path}: {r.status_code} {r.text[:200]}")
        return None
    log.info(f"uploaded {storage_path} ({len(data) / 1024:.1f} KB)")
    return storage_path


def upload_pipeline_outputs(book_id: str, pdf_paths: list[Path]):
    """Push final PDFs to storage under {slug}/."""
    if not _enabled() or not book_id:
        return
    slug = BOOK["slug"]
    for path in pdf_paths:
        if path and path.exists():
            upload_to_storage(path, f"{slug}/{path.name}")
