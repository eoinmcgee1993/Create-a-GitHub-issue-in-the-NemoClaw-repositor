"""
KDP interior PDF assembly.
Builds an 8.5x11 single sided interior with:
  - Page 1: Title
  - Page 2: Copyright and disclaimer
  - Pages 3 to 82: 40 design pages, each followed by a blank back (KDP requirement)
  - Pages 83 to 84: Back matter, About the publisher

Output: output/pdf/{slug}_interior.pdf

Usage:
    python assemble.py
"""
import json
import logging
from pathlib import Path

from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import black

from config import (
    BOOK,
    CLEAN_DIR,
    PDF_DIR,
    TRIM_WIDTH_IN,
    TRIM_HEIGHT_IN,
    LOG_DIR,
    ROOT,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "assemble.log"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("assemble")


PAGE_W = TRIM_WIDTH_IN * inch
PAGE_H = TRIM_HEIGHT_IN * inch


def draw_title_page(c: canvas.Canvas):
    """Title page, page 1."""
    c.setFillColor(black)
    c.setFont("Helvetica-Bold", 42)
    c.drawCentredString(PAGE_W / 2, PAGE_H - 3.5 * inch, BOOK["title"])
    c.setFont("Helvetica", 16)
    # Wrap subtitle manually
    subtitle = BOOK["subtitle"]
    words = subtitle.split()
    lines = []
    current = []
    for w in words:
        current.append(w)
        if len(" ".join(current)) > 50:
            lines.append(" ".join(current[:-1]))
            current = [w]
    if current:
        lines.append(" ".join(current))
    y = PAGE_H - 5 * inch
    for line in lines:
        c.drawCentredString(PAGE_W / 2, y, line)
        y -= 0.3 * inch
    c.setFont("Helvetica-Oblique", 12)
    c.drawCentredString(PAGE_W / 2, 2 * inch, BOOK["imprint"])
    c.showPage()


def draw_copyright_page(c: canvas.Canvas):
    """Copyright page, page 2."""
    c.setFont("Helvetica", 10)
    text = c.beginText(1 * inch, PAGE_H - 2 * inch)
    lines = [
        f"{BOOK['title']}",
        f"{BOOK['series']}, Volume {BOOK['volume']}",
        "",
        f"Copyright (c) {BOOK['year']} {BOOK['author']}",
        f"Published by {BOOK['imprint']}",
        "",
        "All rights reserved. No part of this book may be reproduced, distributed,",
        "or transmitted in any form or by any means, including photocopying,",
        "recording, or other electronic or mechanical methods, without the prior",
        "written permission of the publisher, except in the case of brief quotations",
        "embodied in critical reviews and certain other noncommercial uses permitted",
        "by copyright law.",
        "",
        "Coloring pages in this book are intended for personal, non-commercial use.",
        "",
        f"First Edition, {BOOK['year']}",
        f"Printed by Amazon KDP",
    ]
    for line in lines:
        text.textLine(line)
    c.drawText(text)
    c.showPage()


def draw_design_page(c: canvas.Canvas, image_path: Path):
    """A single design page, full bleed image centered on 8.5x11."""
    c.drawImage(
        str(image_path),
        0,
        0,
        width=PAGE_W,
        height=PAGE_H,
        preserveAspectRatio=False,
        mask=None,
    )
    c.showPage()


def draw_blank_page(c: canvas.Canvas):
    """Pure white blank, no marks. KDP coloring book back-of-page requirement."""
    c.showPage()


def draw_back_matter(c: canvas.Canvas):
    """Back matter, last 2 pages."""
    # Thank you page
    c.setFont("Helvetica-Bold", 24)
    c.drawCentredString(PAGE_W / 2, PAGE_H - 4 * inch, "Thank you for coloring.")
    c.setFont("Helvetica", 12)
    c.drawCentredString(PAGE_W / 2, PAGE_H - 5 * inch, "If you enjoyed this book, please leave a review on Amazon.")
    c.drawCentredString(PAGE_W / 2, PAGE_H - 5.4 * inch, "Reviews help other colorists discover the series.")
    c.showPage()

    # About publisher page
    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(PAGE_W / 2, PAGE_H - 3 * inch, f"About {BOOK['imprint']}")
    c.setFont("Helvetica", 11)
    blurb = [
        f"{BOOK['imprint']} publishes calming bold and easy coloring books",
        "designed for adults, teens, and anyone who finds detailed adult coloring",
        "books overwhelming. Each title in our Cozy Aesthetic series focuses on",
        "thick, forgiving outlines and warm, inviting subject matter.",
        "",
        "Explore the rest of the series on Amazon by searching:",
        f'"{BOOK["series"]}"',
    ]
    y = PAGE_H - 4 * inch
    for line in blurb:
        c.drawCentredString(PAGE_W / 2, y, line)
        y -= 0.25 * inch
    c.showPage()


def build_interior() -> Path:
    """Assemble the full interior PDF and return its path."""
    out_path = PDF_DIR / f"{BOOK['slug']}_interior.pdf"
    c = canvas.Canvas(str(out_path), pagesize=(PAGE_W, PAGE_H))
    c.setTitle(BOOK["title"])
    c.setAuthor(BOOK["author"])
    c.setSubject(BOOK["subtitle"])

    # Front matter
    draw_title_page(c)
    draw_copyright_page(c)

    # Load manifest in canonical order
    manifest = json.loads((ROOT / "prompts.json").read_text())
    prompts = sorted(manifest["prompts"], key=lambda p: p["index"])

    page_count = 2
    missing = []
    for entry in prompts:
        img = CLEAN_DIR / entry["filename"]
        if not img.exists():
            log.warning(f"MISSING {entry['filename']}, inserting placeholder blank")
            missing.append(entry["filename"])
            draw_blank_page(c)
        else:
            draw_design_page(c, img)
        page_count += 1
        # Blank back page (KDP coloring book single-sided requirement)
        draw_blank_page(c)
        page_count += 1

    # Back matter
    draw_back_matter(c)
    page_count += 2

    c.save()
    log.info(f"DONE wrote {out_path.name}, {page_count} pages, {len(missing)} missing assets")
    if missing:
        log.warning("Re-run generate.py + clean.py for these before publishing:")
        for m in missing:
            log.warning(f"  - {m}")
    return out_path


if __name__ == "__main__":
    path = build_interior()
    print(f"Interior PDF: {path}")
