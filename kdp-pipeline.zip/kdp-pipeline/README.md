# DR KDP Pipeline

Fully automated coloring book production for Amazon KDP, end to end from prompt to print ready files.

Built for the Clearmark x Digital Renaissance system. One pipeline, one config edit, and a new book is ready to upload in roughly 10 minutes of wall time and about 4 dollars of image API spend.

## What it does

4 stages, structured around the DR operating principle.

1. **Prompts.** Builds a manifest of 40 prompts from 4 visual pillars (10 each), with consistent bold and easy style suffix and negative prompts to block color and shading.
2. **Generate.** Batches the 40 prompts through Replicate Flux or OpenAI image API, concurrency capped at 4, retry on failure, output saved as raw PNG.
3. **Clean.** Converts each raw image to pure black on pure white, sharpens lines, upscales to 300 DPI for 8.5x11 trim, drops a quality check that rejects any image that came out too dark.
4. **Assemble.** Builds the KDP interior PDF (single sided, 84 pages, title and copyright front matter, blank backs, back matter), generates the front cover art, calculates the spine width from page count, and assembles the full KDP cover wrap PDF. Also writes the KDP listing copy as JSON, ready to paste into the upload form.

## File layout

```
kdp-pipeline/
  config.py              # niche brief, paths, all editable settings
  prompts.py             # builds the 40 prompt manifest
  generate.py            # image API caller, retries and concurrency
  clean.py               # threshold, upscale, KDP ready 300 DPI
  assemble.py            # KDP interior PDF
  cover.py               # cover art + KDP wrap PDF
  listing.py             # title, subtitle, keywords, description JSON
  main.py                # orchestrator
  supabase_schema.sql    # tables for tracking books, runs, designs, sales
  n8n_workflow.json      # workflow to trigger pipeline on webhook
  .env.example           # API key template
  prompts.json           # generated, 40 prompts ready to feed generate.py
  listing.json           # generated, full KDP listing copy
  output/
    raw/                 # raw images from the API
    clean/               # cleaned 300 DPI pages
    pdf/                 # interior + cover wrap PDFs
    logs/                # per stage log files
```

## Setup

```bash
git clone {your repo} kdp-pipeline
cd kdp-pipeline
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env, add your REPLICATE_API_TOKEN
```

## Run

Full run:

```bash
python main.py
```

Skip image generation (re-assemble from existing raws):

```bash
python main.py --skip-generate
```

Just the prompts step (to inspect the manifest):

```bash
python prompts.py
```

Just the listing copy:

```bash
python listing.py
```

## Cost estimate per book

| Stage | Provider | Cost |
|---|---|---|
| 40 design images | Replicate Flux Schnell | ~$0.04 |
| 40 design images | Replicate Flux Dev | ~$1.20 |
| 40 design images | OpenAI gpt-image-1 (medium) | ~$1.60 |
| 1 cover image | Replicate Flux Dev | ~$0.03 |
| 1 cover image | OpenAI gpt-image-1 (high) | ~$0.19 |
| **Total per book (Flux Schnell + Flux Dev cover)** | | **~$0.07** |
| **Total per book (Flux Dev + Flux Dev cover)** | | **~$1.23** |
| **Total per book (OpenAI both)** | | **~$1.79** |

Pricing was current at build time, check provider dashboards for live rates.

## Stacking new books

To spin up book 2 in the series:

1. Open `config.py`
2. Change `BOOK["slug"]`, `BOOK["title"]`, `BOOK["subtitle"]`, `BOOK["volume"]`
3. Rewrite the `PILLARS` subjects for the new theme (10 each, 4 pillars)
4. Update `cover.py`'s `COVER_PROMPT` to match
5. Update `listing.py`'s `LISTING` dict (keywords, description, bullets)
6. Run `python main.py`

Production time per follow on book once the pipeline exists: about 10 minutes wall time, mostly waiting on the image API.

## Where this fits in the DR infrastructure

- **n8n**: import `n8n_workflow.json`, point the executeCommand step at the pipeline directory on your VPS or n8n self host, run on webhook trigger or cron.
- **Supabase**: run `supabase_schema.sql` against your existing DR project, then add the supabase-py client to the pipeline if you want to log each design row.
- **Gumroad**: not directly used here, but the same pipeline can produce a digital download bundle by skipping the cover wrap and selling the interior PDF as a printable.
- **Pinterest**: the `listing.json` includes `pinterest_pin_ideas`, feed these into the existing Pinterest-to-Gumroad workflow with the cover art and sample pages.

## What is manual

KDP itself. There is no public KDP publishing API. Steps that stay manual:

1. Open KDP, create new paperback
2. Paste title, subtitle, author from `listing.json`
3. Paste 7 backend keywords
4. Set the 2 categories
5. Upload the interior PDF
6. Upload the cover wrap PDF
7. Preview, fix any minor issues
8. Set price to 9.99 USD, confirm 60 percent royalty
9. Publish

Total time at the KDP end: about 5 minutes per book once the assets are ready.

## Honest limits

- The image API does sometimes return a design with subtle gray fill or color. The clean step's threshold catches most, but inspect the output folder before assembly. Re-run `generate.py` for any rejected files.
- Flux Schnell is the cheapest path but Flux Dev produces noticeably cleaner line art. Test both with your first book.
- Coloring books are not copyrightable in the same way as text, but the underlying AI training data is a live legal question. Keep the prompts away from named characters, branded properties, and recognizable real people.
- KDP can reject low quality interiors. The first book in any series, expect 1 round of revision after KDP review feedback.
