"""
Placeholder line art generator (demo only).
Generates 40 simple bold and easy style coloring book pages using PIL primitives
so the rest of the pipeline can be tested end to end without an image API key.

Replace this step in production with generate.py (real image API calls).

Usage:
    python placeholder_art.py
"""
import json
import math
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from config import RAW_DIR, ROOT


SIZE = 1024
LINE_WIDTH = 7  # bold and easy = thick lines


def _setup_canvas():
    img = Image.new("RGB", (SIZE, SIZE), "white")
    return img, ImageDraw.Draw(img)


def draw_cottage(d: ImageDraw.ImageDraw, idx: int):
    """Simple cottage with roof, door, window, chimney."""
    cx, cy = SIZE // 2, SIZE // 2 + 50
    w, h = 500, 320
    # House body
    d.rectangle([cx - w // 2, cy - h // 2, cx + w // 2, cy + h // 2],
                outline="black", width=LINE_WIDTH)
    # Roof (triangle)
    d.polygon([(cx - w // 2 - 30, cy - h // 2),
               (cx, cy - h // 2 - 200),
               (cx + w // 2 + 30, cy - h // 2)],
              outline="black", width=LINE_WIDTH)
    # Door
    door_w, door_h = 110, 180
    d.rectangle([cx - door_w // 2, cy + h // 2 - door_h, cx + door_w // 2, cy + h // 2],
                outline="black", width=LINE_WIDTH)
    d.ellipse([cx + 25, cy + h // 2 - door_h // 2 - 8, cx + 40, cy + h // 2 - door_h // 2 + 7],
              outline="black", width=LINE_WIDTH - 2)
    # Windows
    for sx in (cx - 150, cx + 150):
        d.rectangle([sx - 50, cy - 70, sx + 50, cy + 30],
                    outline="black", width=LINE_WIDTH)
        d.line([sx, cy - 70, sx, cy + 30], fill="black", width=LINE_WIDTH - 2)
        d.line([sx - 50, cy - 20, sx + 50, cy - 20], fill="black", width=LINE_WIDTH - 2)
    # Chimney
    d.rectangle([cx + 100, cy - h // 2 - 140, cx + 160, cy - h // 2 - 30],
                outline="black", width=LINE_WIDTH)
    # Smoke
    for i, r in enumerate([28, 35, 42]):
        d.ellipse([cx + 130 - r + i * 25, cy - h // 2 - 230 - i * 40,
                   cx + 130 + r + i * 25, cy - h // 2 - 170 - i * 40],
                  outline="black", width=LINE_WIDTH - 2)
    # Path
    d.line([cx, cy + h // 2, cx, cy + h // 2 + 200], fill="black", width=LINE_WIDTH)
    d.line([cx - 60, cy + h // 2 + 200, cx + 60, cy + h // 2 + 200],
           fill="black", width=LINE_WIDTH)


def draw_woodland(d: ImageDraw.ImageDraw, idx: int):
    """Simple woodland creature (round body, ears, eyes)."""
    cx, cy = SIZE // 2, SIZE // 2 + 30
    # Body
    d.ellipse([cx - 220, cy - 100, cx + 220, cy + 280],
              outline="black", width=LINE_WIDTH)
    # Head
    d.ellipse([cx - 170, cy - 280, cx + 170, cy + 60],
              outline="black", width=LINE_WIDTH)
    # Ears
    d.ellipse([cx - 170, cy - 360, cx - 80, cy - 200],
              outline="black", width=LINE_WIDTH)
    d.ellipse([cx + 80, cy - 360, cx + 170, cy - 200],
              outline="black", width=LINE_WIDTH)
    d.ellipse([cx - 155, cy - 340, cx - 95, cy - 230],
              outline="black", width=LINE_WIDTH - 2)
    d.ellipse([cx + 95, cy - 340, cx + 155, cy - 230],
              outline="black", width=LINE_WIDTH - 2)
    # Eyes
    d.ellipse([cx - 80, cy - 160, cx - 40, cy - 110],
              outline="black", width=LINE_WIDTH, fill="black")
    d.ellipse([cx + 40, cy - 160, cx + 80, cy - 110],
              outline="black", width=LINE_WIDTH, fill="black")
    # Nose
    d.ellipse([cx - 18, cy - 80, cx + 18, cy - 50],
              outline="black", width=LINE_WIDTH - 2, fill="black")
    # Mouth
    d.arc([cx - 40, cy - 60, cx, cy - 20], 0, 180, fill="black", width=LINE_WIDTH - 2)
    d.arc([cx, cy - 60, cx + 40, cy - 20], 0, 180, fill="black", width=LINE_WIDTH - 2)
    # Flower
    fcx, fcy = cx + 200, cy + 130
    for angle in range(0, 360, 60):
        rad = math.radians(angle)
        px = fcx + int(40 * math.cos(rad))
        py = fcy + int(40 * math.sin(rad))
        d.ellipse([px - 25, py - 25, px + 25, py + 25],
                  outline="black", width=LINE_WIDTH - 2)
    d.ellipse([fcx - 20, fcy - 20, fcx + 20, fcy + 20],
              outline="black", width=LINE_WIDTH - 2)


def draw_mushroom(d: ImageDraw.ImageDraw, idx: int):
    """Friendly mushroom with spots."""
    cx, cy = SIZE // 2, SIZE // 2 + 100
    # Cap
    d.pieslice([cx - 250, cy - 280, cx + 250, cy + 80],
               180, 360, outline="black", width=LINE_WIDTH)
    # Cap underside line
    d.line([cx - 250, cy - 100, cx + 250, cy - 100], fill="black", width=LINE_WIDTH)
    # Stem
    d.rectangle([cx - 90, cy - 100, cx + 90, cy + 240],
                outline="black", width=LINE_WIDTH)
    # Stem curve at base
    d.arc([cx - 130, cy + 200, cx - 50, cy + 280], 0, 90, fill="black", width=LINE_WIDTH)
    d.arc([cx + 50, cy + 200, cx + 130, cy + 280], 90, 180, fill="black", width=LINE_WIDTH)
    # Spots
    random.seed(idx)
    for _ in range(5):
        sx = cx + random.randint(-180, 180)
        sy = cy + random.randint(-220, -130)
        r = random.randint(25, 45)
        d.ellipse([sx - r, sy - r, sx + r, sy + r],
                  outline="black", width=LINE_WIDTH - 2)
    # Grass at base
    for offset in range(-200, 220, 60):
        d.line([cx + offset, cy + 280, cx + offset - 10, cy + 240],
               fill="black", width=LINE_WIDTH - 3)
        d.line([cx + offset, cy + 280, cx + offset + 10, cy + 240],
               fill="black", width=LINE_WIDTH - 3)
    # Smile on cap
    d.arc([cx - 50, cy - 220, cx + 50, cy - 170], 0, 180,
          fill="black", width=LINE_WIDTH - 2)


def draw_garden(d: ImageDraw.ImageDraw, idx: int):
    """Wildflower garden with watering can or flowers."""
    cx, cy = SIZE // 2, SIZE // 2

    # Three tall flower stems
    positions = [-200, 0, 200]
    for px in positions:
        # Stem
        d.line([cx + px, cy + 250, cx + px, cy - 50], fill="black", width=LINE_WIDTH)
        # Flower head (varies by position)
        if px == -200:
            # Tulip
            d.arc([cx + px - 60, cy - 150, cx + px + 60, cy - 50], 180, 360,
                  fill="black", width=LINE_WIDTH)
            d.line([cx + px - 60, cy - 100, cx + px - 20, cy - 150],
                   fill="black", width=LINE_WIDTH)
            d.line([cx + px + 60, cy - 100, cx + px + 20, cy - 150],
                   fill="black", width=LINE_WIDTH)
            d.line([cx + px, cy - 50, cx + px, cy - 150],
                   fill="black", width=LINE_WIDTH)
        elif px == 0:
            # Daisy
            for angle in range(0, 360, 45):
                rad = math.radians(angle)
                ex = cx + px + int(80 * math.cos(rad))
                ey = cy - 100 + int(80 * math.sin(rad))
                d.ellipse([ex - 30, ey - 20, ex + 30, ey + 20],
                          outline="black", width=LINE_WIDTH - 2)
            d.ellipse([cx + px - 25, cy - 125, cx + px + 25, cy - 75],
                      outline="black", width=LINE_WIDTH)
        else:
            # Sunflower
            for angle in range(0, 360, 30):
                rad = math.radians(angle)
                ex = cx + px + int(80 * math.cos(rad))
                ey = cy - 100 + int(80 * math.sin(rad))
                d.polygon([
                    (ex - 25, ey),
                    (ex + 25, ey - 10),
                    (ex + 25, ey + 10),
                ], outline="black", width=LINE_WIDTH - 2)
            d.ellipse([cx + px - 50, cy - 150, cx + px + 50, cy - 50],
                      outline="black", width=LINE_WIDTH)
        # Leaves on stem
        d.ellipse([cx + px - 40, cy + 80, cx + px - 5, cy + 140],
                  outline="black", width=LINE_WIDTH - 2)
        d.ellipse([cx + px + 5, cy + 30, cx + px + 40, cy + 90],
                  outline="black", width=LINE_WIDTH - 2)
    # Ground line
    d.line([100, cy + 260, SIZE - 100, cy + 260], fill="black", width=LINE_WIDTH)
    # Butterflies
    for bx, by in [(150, 200), (SIZE - 200, 250)]:
        d.ellipse([bx - 30, by - 25, bx, by + 5],
                  outline="black", width=LINE_WIDTH - 2)
        d.ellipse([bx, by - 25, bx + 30, by + 5],
                  outline="black", width=LINE_WIDTH - 2)
        d.ellipse([bx - 25, by - 5, bx - 5, by + 20],
                  outline="black", width=LINE_WIDTH - 2)
        d.ellipse([bx + 5, by - 5, bx + 25, by + 20],
                  outline="black", width=LINE_WIDTH - 2)


PILLAR_DRAWERS = {
    "cottages": draw_cottage,
    "woodland": draw_woodland,
    "mushrooms": draw_mushroom,
    "garden": draw_garden,
}


def generate_all():
    manifest = json.loads((ROOT / "prompts.json").read_text())
    for entry in manifest["prompts"]:
        img, d = _setup_canvas()
        drawer = PILLAR_DRAWERS[entry["pillar"]]
        drawer(d, entry["index"])
        # Border tweak so each design varies subtly
        if entry["pillar_position"] % 3 == 0:
            d.rectangle([20, 20, SIZE - 20, SIZE - 20],
                        outline="black", width=LINE_WIDTH - 4)
        out_path = RAW_DIR / entry["filename"]
        img.save(out_path)
        entry["status"] = "ok"
    (ROOT / "prompts.json").write_text(json.dumps(manifest, indent=2))
    print(f"Generated {len(manifest['prompts'])} placeholder line art images in {RAW_DIR}")


if __name__ == "__main__":
    generate_all()
