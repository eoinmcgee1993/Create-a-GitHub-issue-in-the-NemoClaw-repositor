-- DR KDP Pipeline schema
-- Run in Supabase SQL editor against your existing project

create extension if not exists "uuid-ossp";

-- Each book = one row
create table if not exists kdp_books (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,
  series text,
  volume int,
  title text not null,
  subtitle text,
  author text,
  list_price_usd numeric(6,2),
  trim text default '8.5x11',
  page_count int,
  design_count int default 40,
  asin text,
  amazon_url text,
  status text default 'planned',
    -- planned | generating | cleaned | assembled | uploaded | live
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  published_at timestamptz,
  niche_brief jsonb,
  listing_payload jsonb
);

-- One row per pipeline run (for cost tracking)
create table if not exists kdp_pipeline_runs (
  id uuid primary key default uuid_generate_v4(),
  book_id uuid references kdp_books(id) on delete cascade,
  stage text not null,    -- prompts | generate | clean | assemble | cover | listing
  status text not null,   -- ok | failed | partial
  duration_seconds int,
  cost_usd numeric(8,4),
  notes jsonb,
  created_at timestamptz default now()
);

-- One row per design (40 per book)
create table if not exists kdp_designs (
  id uuid primary key default uuid_generate_v4(),
  book_id uuid references kdp_books(id) on delete cascade,
  index int not null,
  pillar text not null,
  subject text not null,
  prompt text not null,
  raw_url text,        -- supabase storage path to raw image
  clean_url text,      -- supabase storage path to cleaned image
  status text default 'pending',
  retries int default 0,
  generated_at timestamptz,
  unique (book_id, index)
);

-- Sales tracking (optional, populated by n8n + KDP report ingest)
create table if not exists kdp_sales_daily (
  id uuid primary key default uuid_generate_v4(),
  book_id uuid references kdp_books(id) on delete cascade,
  date date not null,
  units int default 0,
  revenue_usd numeric(10,2) default 0,
  royalty_usd numeric(10,2) default 0,
  marketplace text default 'US',
  unique (book_id, date, marketplace)
);

-- View: quick portfolio summary
create or replace view kdp_portfolio as
select
  b.slug,
  b.title,
  b.status,
  b.asin,
  coalesce(sum(s.units), 0) as total_units,
  coalesce(sum(s.royalty_usd), 0) as total_royalty,
  coalesce(sum(case when s.date > now() - interval '30 days' then s.royalty_usd else 0 end), 0) as last_30d_royalty
from kdp_books b
left join kdp_sales_daily s on s.book_id = b.id
group by b.id;
