"""
Pipeline configuration for the Clearmark x DR KDP system.
All niche brief variables, paths, and runtime settings live here.
Edit this file to spin up a new book in the same pipeline.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ----- Project paths -----
ROOT = Path(__file__).resolve().parent
RAW_DIR = ROOT / "output" / "raw"
CLEAN_DIR = ROOT / "output" / "clean"
PDF_DIR = ROOT / "output" / "pdf"
LOG_DIR = ROOT / "output" / "logs"

for d in (RAW_DIR, CLEAN_DIR, PDF_DIR, LOG_DIR):
    d.mkdir(parents=True, exist_ok=True)

# ----- API keys (load from .env) -----
REPLICATE_API_TOKEN = os.getenv("REPLICATE_API_TOKEN", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_KEY", "")

# ----- Image generation -----
# Provider options: "replicate_flux_schnell", "replicate_flux_dev", "openai_gpt_image"
IMAGE_PROVIDER = os.getenv("IMAGE_PROVIDER", "replicate_flux_schnell")
IMAGE_SIZE = 1024  # square output, upscaled and cropped to trim during clean step
CONCURRENT_REQUESTS = 4  # 4 at a time, matches DR operating principle
RETRY_LIMIT = 3

# ----- KDP interior specs -----
TRIM_WIDTH_IN = 8.5
TRIM_HEIGHT_IN = 11.0
BLEED_IN = 0.125
DPI = 300
TRIM_W_PX = int(TRIM_WIDTH_IN * DPI)        # 2550
TRIM_H_PX = int(TRIM_HEIGHT_IN * DPI)       # 3300
BLEED_PX = int(BLEED_IN * DPI)              # 38
SAFE_MARGIN_IN = 0.375                       # KDP safe zone for paperback
SAFE_MARGIN_PX = int(SAFE_MARGIN_IN * DPI)  # 113

# ----- Book metadata (Niche Brief output) -----
BOOK = {
    "slug": "cozy_cottagecore_bold_easy",
    "series": "DR Cozy Aesthetic Coloring Series",
    "volume": 1,
    "title": "Cozy Cottagecore",
    "subtitle": (
        "Bold & Easy Coloring Book for Adults and Teens, "
        "40 Charming Designs of Cottages, Mushrooms, and Woodland Magic"
    ),
    "author": "Eoin McGee",
    "imprint": "Digital Renaissance Press",
    "year": 2026,
    "list_price_usd": 9.99,
    "page_count_target": 84,         # 2 front matter, 80 design + blank pairs, 2 back matter
    "design_count": 40,
    "trim": "8.5x11",
}

# ----- 4 visual pillars, 10 designs each -----
PILLARS = [
    {
        "id": "cottages",
        "name": "Cottages and Cozy Interiors",
        "count": 10,
        "subjects": [
            "a small thatched stone cottage with smoke curling from the chimney",
            "a cozy kitchen interior with a wood stove and hanging copper pots",
            "a reading nook with a window seat, stack of books, and a sleeping cat",
            "a stone cottage doorway with climbing roses and a welcome mat",
            "a fireplace with a kettle on the hook, knitting basket beside it",
            "an attic bedroom with a quilted bed and a round window",
            "a cottage front porch with a rocking chair and potted herbs",
            "a tea table by a sunny window with a teapot, scones, and jam",
            "a cottage hallway with a coat rack, boots, and a vase of dried flowers",
            "a quaint thatched bakery shopfront with bread loaves in the window",
        ],
    },
    {
        "id": "woodland",
        "name": "Woodland Creatures",
        "count": 10,
        "subjects": [
            "a friendly rabbit holding a wildflower in a meadow",
            "a fox curled up sleeping among ferns and clover",
            "a hedgehog wearing a tiny scarf carrying a basket of berries",
            "a deer with flowers tucked behind its ears in a sunlit glade",
            "a chipmunk peeking from a hollow log with acorns",
            "a family of mice having a picnic on a mushroom",
            "a barn owl perched on a branch with stars in the background",
            "a badger reading a small book by a tree stump",
            "a squirrel balancing on a branch with a pinecone",
            "a frog sitting on a lily pad with cattails and dragonflies",
        ],
    },
    {
        "id": "mushrooms",
        "name": "Mushrooms and Forest Floor",
        "count": 10,
        "subjects": [
            "a cluster of amanita mushrooms with spots and curling ferns",
            "a tall single toadstool with a tiny door and round window",
            "a ring of small mushrooms growing on a mossy log",
            "a chanterelle mushroom patch with fallen leaves",
            "a giant portobello with snails and beetles around the base",
            "an oyster mushroom shelf growing on a tree trunk",
            "morel mushrooms in a forest clearing with sunbeams",
            "a fairy ring of tiny mushrooms with a path through the middle",
            "a pumpkin sitting in a patch of mushrooms and pinecones",
            "a stack of three different mushrooms with vines twisting around them",
        ],
    },
    {
        "id": "garden",
        "name": "Wildflowers and Kitchen Garden",
        "count": 10,
        "subjects": [
            "a watering can pouring over a bed of tulips and daisies",
            "a wicker basket overflowing with herbs and wildflowers",
            "a wooden garden gate framed by climbing wisteria",
            "a row of terracotta pots with rosemary, basil, and thyme labels",
            "a sunflower patch with bees and butterflies",
            "a vintage bicycle with a flower basket leaning on a fence",
            "a beehive with bees and clover flowers around it",
            "a vegetable harvest table with carrots, beetroot, and onions",
            "a window box bursting with geraniums and trailing ivy",
            "a wild meadow scene with poppies, lavender, and dandelions",
        ],
    },
]

# Style suffix applied to every prompt for consistent bold and easy line art
STYLE_SUFFIX = (
    "bold and easy coloring book page, thick clean black outlines (4 to 5 pixels), "
    "pure white background, no shading, no fill, no color, no gray, no gradients, "
    "simple cute shapes, flat 2D illustration, kawaii style, large open areas for coloring, "
    "kid friendly, beginner friendly, single illustration centered on page, "
    "vector style line art, no text, no watermark"
)

NEGATIVE_PROMPT = (
    "color, shading, gradient, fill, gray, grayscale, watercolor, paint, "
    "photograph, realistic, 3d render, text, signature, watermark, frame, border, "
    "multiple panels, comic, complex detail, hatching, crosshatching"
)
