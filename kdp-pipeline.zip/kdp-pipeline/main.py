"""
Pipeline orchestrator.
Runs all 4 stages in order:
  1. Generate the 40 prompts manifest
  2. Generate the 40 raw images via image API
  3. Clean each image to KDP ready 300 DPI pure B&W
  4. Assemble the interior PDF, cover wrap, and listing copy

Usage:
    python main.py                    # full run
    python main.py --skip-generate    # use existing raw images
    python main.py --skip-cover       # skip cover generation
"""
import argparse
import asyncio
import json
import os
import sys
import time
from pathlib import Path

from prompts import save_manifest
from generate import run_all as generate_all
from clean import run_all as clean_all
from assemble import build_interior
from cover import generate_front_cover_art, assemble_wrap
from listing import save as save_listing
from config import BOOK, ROOT, IMAGE_PROVIDER
from supabase_client import (
    get_or_create_book,
    update_book_status,
    log_run,
    upsert_designs,
    upload_pipeline_outputs,
)

GITHUB_RUN_ID = os.getenv("GITHUB_RUN_ID")


def banner(msg: str):
    bar = "=" * 60
    print(f"\n{bar}\n  {msg}\n{bar}")


async def run(args):
    banner(f"DR KDP PIPELINE: {BOOK['title']}")
    start_time = time.time()

    # Register book in Supabase (creates row if missing)
    book_id = get_or_create_book()
    if book_id:
        update_book_status(book_id, "generating")

    # Stage 1: prompts manifest
    banner("STAGE 1 of 4: build prompts manifest")
    stage_start = time.time()
    manifest_path = save_manifest()
    data = json.loads(manifest_path.read_text())
    print(f"Wrote {manifest_path}, {data['design_count']} prompts ready")
    if book_id:
        upsert_designs(book_id, data)
        log_run(book_id, "prompts", "ok", int(time.time() - stage_start),
                provider=IMAGE_PROVIDER, github_run_id=GITHUB_RUN_ID)

    # Stage 2: image generation
    if args.skip_generate:
        print("\nSKIP stage 2 (--skip-generate)")
    else:
        banner("STAGE 2 of 4: generate 40 raw images")
        stage_start = time.time()
        try:
            await generate_all()
            if book_id:
                log_run(book_id, "generate", "ok", int(time.time() - stage_start),
                        provider=IMAGE_PROVIDER, github_run_id=GITHUB_RUN_ID)
        except Exception as exc:
            if book_id:
                log_run(book_id, "generate", "failed", int(time.time() - stage_start),
                        notes={"error": str(exc)}, github_run_id=GITHUB_RUN_ID)
                update_book_status(book_id, "failed")
            raise

    # Stage 3: clean
    banner("STAGE 3 of 4: clean and threshold to KDP ready")
    stage_start = time.time()
    result = clean_all()
    if result["rejected"]:
        print(f"WARNING {len(result['rejected'])} files rejected, may need regeneration")
    if book_id:
        log_run(book_id, "clean",
                "partial" if result["rejected"] else "ok",
                int(time.time() - stage_start),
                notes={"rejected": result["rejected"]},
                github_run_id=GITHUB_RUN_ID)

    # Stage 4: assemble
    banner("STAGE 4 of 4: assemble interior, cover, and listing")
    stage_start = time.time()
    interior = build_interior()
    print(f"Interior PDF: {interior}")

    cover_wrap = None
    if not args.skip_cover:
        front = await generate_front_cover_art()
        cover_wrap = assemble_wrap(front, BOOK["page_count_target"])
        print(f"Cover wrap: {cover_wrap}")

    listing_path = save_listing()
    print(f"Listing JSON: {listing_path}")

    if book_id:
        log_run(book_id, "assemble", "ok", int(time.time() - stage_start),
                github_run_id=GITHUB_RUN_ID)
        # Upload final PDFs to storage
        upload_pipeline_outputs(book_id, [interior, cover_wrap])
        update_book_status(book_id, "assembled", extra={
            "listing_payload": json.loads(listing_path.read_text()),
        })
        log_run(book_id, "full_run", "ok", int(time.time() - start_time),
                provider=IMAGE_PROVIDER, github_run_id=GITHUB_RUN_ID)

    banner("DONE. KDP upload checklist:")
    print(f"  [ ] Upload interior:    output/pdf/{BOOK['slug']}_interior.pdf")
    print(f"  [ ] Upload cover wrap:  output/pdf/{BOOK['slug']}_cover_wrap.pdf")
    print(f"  [ ] Copy listing from:  listing.json")
    print(f"  [ ] Set list price:     ${BOOK['list_price_usd']}")
    print(f"  [ ] Trim size:          {BOOK['trim']}")
    print(f"  [ ] Interior:           Black & white, white paper")
    if book_id:
        print(f"\nSupabase book row: {book_id}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-generate", action="store_true", help="Use existing raw images")
    parser.add_argument("--skip-cover", action="store_true", help="Skip cover generation")
    args = parser.parse_args()
    asyncio.run(run(args))


if __name__ == "__main__":
    main()
