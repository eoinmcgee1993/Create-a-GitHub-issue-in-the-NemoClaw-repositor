"""
Cover generator.
Two outputs:
  1. Front cover image only (for ads, Pinterest, A+ content)
  2. Full KDP wrap PDF, front + spine + back, sized for the printed page count

Spine width formula (KDP white paper, black ink):
  spine_in = page_count * 0.002252

Trim for full wrap PDF:
  width  = 0.125 (bleed) + 8.5 (back) + spine + 8.5 (front) + 0.125 (bleed)
  height = 0.125 (bleed) + 11.0 + 0.125 (bleed)

Usage:
    python cover.py
"""
import asyncio
import base64
import logging
from pathlib import Path

import httpx
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.colors import HexColor, white, black

from config import (
    BOOK,
    PDF_DIR,
    LOG_DIR,
    DPI,
    REPLICATE_API_TOKEN,
    OPENAI_API_KEY,
    IMAGE_PROVIDER,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[logging.FileHandler(LOG_DIR / "cover.log"), logging.StreamHandler()],
)
log = logging.getLogger("cover")


COVER_PROMPT = (
    "A 2 by 3 grid of small cute coloring book illustrations on a warm terracotta and sage green background. "
    "Each tile shows a different cozy cottagecore scene: a thatched cottage, a smiling mushroom, "
    "a rabbit holding a flower, a watering can with tulips, a teapot with steam, and a hedgehog with a basket. "
    "Half the tiles are shown as black line art on white, half are shown lightly colored to demonstrate the coloring style. "
    "Clean modern design, no text in the illustrations, magazine cover quality, "
    "warm autumn palette, terracotta orange and sage green and cream, top down view"
)


# ---------- Front cover image generation ----------
async def generate_front_cover_art() -> Path:
    out_path = PDF_DIR / f"{BOOK['slug']}_front_cover_art.png"
    if out_path.exists():
        log.info(f"SKIP existing {out_path.name}")
        return out_path

    if IMAGE_PROVIDER.startswith("replicate"):
        png_bytes = await _replicate_cover(COVER_PROMPT)
    else:
        png_bytes = await _openai_cover(COVER_PROMPT)

    out_path.write_bytes(png_bytes)
    log.info(f"OK   front cover art: {out_path.name}")
    return out_path


async def _replicate_cover(prompt: str) -> bytes:
    if not REPLICATE_API_TOKEN:
        raise RuntimeError("REPLICATE_API_TOKEN not set")
    headers = {
        "Authorization": f"Bearer {REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
        "Prefer": "wait",
    }
    payload = {
        "input": {
            "prompt": prompt,
            "aspect_ratio": "3:4",
            "output_format": "png",
            "output_quality": 100,
        }
    }
    async with httpx.AsyncClient() as client:
        r = await client.post(
            "https://api.replicate.com/v1/models/black-forest-labs/flux-dev/predictions",
            headers=headers,
            json=payload,
            timeout=180,
        )
        r.raise_for_status()
        data = r.json()
        while data.get("status") in ("starting", "processing"):
            await asyncio.sleep(2)
            poll = await client.get(data["urls"]["get"], headers=headers, timeout=60)
            data = poll.json()
        image_url = data["output"][0] if isinstance(data["output"], list) else data["output"]
        img = await client.get(image_url, timeout=60)
        return img.content


async def _openai_cover(prompt: str) -> bytes:
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY not set")
    async with httpx.AsyncClient() as client:
        r = await client.post(
            "https://api.openai.com/v1/images/generations",
            headers={"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"},
            json={"model": "gpt-image-1", "prompt": prompt, "size": "1024x1536", "n": 1, "quality": "high"},
            timeout=180,
        )
        r.raise_for_status()
        return base64.b64decode(r.json()["data"][0]["b64_json"])


# ---------- KDP full wrap assembly ----------
def calculate_spine_width(page_count: int) -> float:
    """KDP white paper, black ink. Returns inches."""
    return page_count * 0.002252


def assemble_wrap(front_art_path: Path, page_count: int) -> Path:
    """Assemble the full KDP cover wrap PDF."""
    spine_w = calculate_spine_width(page_count)
    bleed = 0.125
    trim_h = 11.0
    trim_w = 8.5

    total_w = (bleed * 2) + (trim_w * 2) + spine_w
    total_h = trim_h + (bleed * 2)

    out_path = PDF_DIR / f"{BOOK['slug']}_cover_wrap.pdf"
    c = canvas.Canvas(str(out_path), pagesize=(total_w * inch, total_h * inch))

    # Background fill (warm terracotta)
    c.setFillColor(HexColor("#D97B57"))
    c.rect(0, 0, total_w * inch, total_h * inch, fill=1, stroke=0)

    # Front cover region (right side after back + spine)
    front_x = (bleed + trim_w + spine_w) * inch
    front_y = bleed * inch
    front_w = trim_w * inch
    front_h = trim_h * inch
    c.drawImage(str(front_art_path), front_x, front_y, width=front_w, height=front_h,
                preserveAspectRatio=True, anchor='c')

    # Title text on front
    c.setFillColor(HexColor("#FAF6EF"))
    c.setFont("Helvetica-Bold", 48)
    c.drawCentredString(front_x + front_w / 2, front_y + front_h - 1.5 * inch, BOOK["title"])
    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(front_x + front_w / 2, front_y + front_h - 2.1 * inch, "BOLD & EASY COLORING BOOK")

    # Spine text
    spine_x = (bleed + trim_w) * inch
    c.saveState()
    c.translate(spine_x + (spine_w * inch) / 2, total_h * inch / 2)
    c.rotate(90)
    c.setFillColor(HexColor("#FAF6EF"))
    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(0, 0, f"{BOOK['title'].upper()}   |   {BOOK['author'].upper()}")
    c.restoreState()

    # Back cover blurb
    back_x = bleed * inch
    back_w = trim_w * inch
    c.setFillColor(HexColor("#FAF6EF"))
    c.setFont("Helvetica-Bold", 20)
    c.drawString(back_x + 0.75 * inch, total_h * inch - 1.5 * inch, "Cozy up.")
    c.drawString(back_x + 0.75 * inch, total_h * inch - 1.9 * inch, "Slow down.")
    c.drawString(back_x + 0.75 * inch, total_h * inch - 2.3 * inch, "Color something charming.")
    c.setFont("Helvetica", 11)
    blurb_lines = [
        "40 bold and easy designs of cottages, woodland creatures,",
        "mushrooms, and wildflowers, drawn with thick beginner",
        "friendly outlines and large open areas for stress free coloring.",
        "",
        "Inside you will find:",
        "  - 40 unique cottagecore illustrations",
        "  - Single sided pages so markers do not bleed through",
        "  - Thick clean lines, kind to all skill levels",
        "  - Perfect for stress relief, mindfulness, and quiet evenings",
        "",
        "A relaxing escape into the cozy cottagecore aesthetic.",
    ]
    y = total_h * inch - 3 * inch
    for line in blurb_lines:
        c.drawString(back_x + 0.75 * inch, y, line)
        y -= 0.22 * inch

    c.save()
    log.info(f"OK   cover wrap: {out_path.name} ({total_w:.2f} x {total_h:.2f} in, spine {spine_w:.3f} in)")
    return out_path


async def main():
    front_art = await generate_front_cover_art()
    assemble_wrap(front_art, BOOK["page_count_target"])


if __name__ == "__main__":
    asyncio.run(main())
