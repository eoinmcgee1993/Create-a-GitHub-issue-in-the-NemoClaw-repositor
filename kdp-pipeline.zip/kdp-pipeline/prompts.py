"""
Generates the 40 design prompts from the 4 pillars in config.PILLARS.
Outputs a manifest JSON the rest of the pipeline consumes.
Run standalone with: python prompts.py
"""
import json
from pathlib import Path
from config import PILLARS, STYLE_SUFFIX, NEGATIVE_PROMPT, BOOK, ROOT


def build_prompts() -> list[dict]:
    manifest = []
    index = 1
    for pillar in PILLARS:
        for i, subject in enumerate(pillar["subjects"], start=1):
            prompt_text = f"{subject}, {STYLE_SUFFIX}"
            manifest.append({
                "index": index,
                "pillar": pillar["id"],
                "pillar_position": i,
                "subject": subject,
                "prompt": prompt_text,
                "negative_prompt": NEGATIVE_PROMPT,
                "filename": f"{pillar['id']}_{i:02d}.png",
                "status": "pending",
            })
            index += 1
    return manifest


def save_manifest(path: Path | None = None) -> Path:
    manifest = build_prompts()
    out_path = path or (ROOT / "prompts.json")
    payload = {
        "book": BOOK,
        "design_count": len(manifest),
        "prompts": manifest,
    }
    out_path.write_text(json.dumps(payload, indent=2))
    return out_path


if __name__ == "__main__":
    out = save_manifest()
    print(f"Wrote {out}")
    data = json.loads(out.read_text())
    print(f"Total prompts: {data['design_count']}")
    for p in data["prompts"][:4]:
        print(f"  {p['index']:02d} [{p['pillar']}] {p['subject'][:60]}")
    print("  ...")
