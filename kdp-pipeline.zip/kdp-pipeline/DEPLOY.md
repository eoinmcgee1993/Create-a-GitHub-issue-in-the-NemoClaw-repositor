# DR KDP Pipeline: Deployment Guide

End to end architecture and setup steps for the production deployment.

## Architecture

```
n8n cloud webhook (mcgeezer81.app.n8n.cloud)
        |
        | 1. mark book queued in Supabase
        | 2. fire repository_dispatch
        v
GitHub Actions runner
        |
        | runs main.py
        | (Replicate Flux + PIL + ReportLab)
        v
Supabase
   - dr_kdp_books (status updates)
   - dr_kdp_designs (one row per page)
   - dr_kdp_pipeline_runs (cost + duration tracking)
   - storage bucket dr-kdp-assets (final PDFs)
        |
        v
Eoin downloads PDFs from Supabase storage or GitHub artifacts
Eoin uploads to KDP (5 minutes manual)
```

## What is already deployed

The Supabase project `eoinmcgee1993@gmail.com` (id `ohcclvcjdbftlnyrrzvt`) has:

- 4 tables: `dr_kdp_books`, `dr_kdp_pipeline_runs`, `dr_kdp_designs`, `dr_kdp_sales_daily`
- 1 view: `dr_kdp_portfolio` (running totals per book)
- 1 storage bucket: `dr-kdp-assets` (private)
- RLS policies: service role full access on all tables and storage
- 1 seeded book row: `cozy_cottagecore_bold_easy`, status `planned`

Verify in your Supabase dashboard:
https://supabase.com/dashboard/project/ohcclvcjdbftlnyrrzvt/editor

## What you need to deploy

### 1. Push the pipeline to a GitHub repo (5 minutes)

```bash
cd kdp-pipeline
git init
git add .
git commit -m "DR KDP pipeline v1"
gh repo create digital-renaissance-kdp --private --source=. --push
# or use the GitHub web UI to create a private repo, then:
# git remote add origin git@github.com:mcgeezer81/digital-renaissance-kdp.git
# git push -u origin main
```

### 2. Add GitHub secrets (3 minutes)

In the repo: Settings -> Secrets and variables -> Actions -> New repository secret.

Add 4 secrets:

| Secret name | Value | Where to find it |
|---|---|---|
| `REPLICATE_API_TOKEN` | r8_... | https://replicate.com/account/api-tokens |
| `OPENAI_API_KEY` | sk-... (optional, for OpenAI image path) | https://platform.openai.com/api-keys |
| `SUPABASE_URL` | https://ohcclvcjdbftlnyrrzvt.supabase.co | already known |
| `SUPABASE_SERVICE_KEY` | eyJ... (service role key, not anon) | Supabase dashboard -> Project Settings -> API |

Optional repository variable (not a secret):

| Variable name | Value |
|---|---|
| `IMAGE_PROVIDER` | `replicate_flux_schnell` for cheap, `replicate_flux_dev` for better quality |

### 3. Test the pipeline manually (10 minutes)

In the GitHub repo: Actions -> Produce KDP Book -> Run workflow.

Fill in:
- Book slug: `cozy_cottagecore_bold_easy`
- Skip generate: false
- Skip cover: false

Run. Watch the live log. Expected wall time about 8 to 12 minutes.

When done, the workflow uploads 3 artifacts:
- `kdp-interior-{run_id}` (the 84 page interior PDF)
- `kdp-cover-{run_id}` (the full cover wrap PDF)
- `kdp-listing-{run_id}` (listing.json)

Plus all final PDFs land in Supabase storage at `dr-kdp-assets/cozy_cottagecore_bold_easy/`.

### 4. Generate a personal access token for n8n (2 minutes)

GitHub -> Settings -> Developer settings -> Personal access tokens -> Fine grained tokens -> Generate new token.

Scope:
- Repository access: only `digital-renaissance-kdp`
- Permissions: Contents (read), Metadata (read), Actions (write)

Copy the token. You will paste it as an n8n environment variable.

### 5. Import the n8n workflow (5 minutes)

Go to https://mcgeezer81.app.n8n.cloud -> Workflows -> Import from File -> select `n8n_workflow.json`.

After import, set 4 n8n credentials or environment variables (Settings -> Variables):

| Variable | Value |
|---|---|
| `SUPABASE_SERVICE_KEY` | Same as the GitHub secret |
| `GITHUB_TOKEN` | The personal access token from step 4 |
| `GITHUB_OWNER` | `mcgeezer81` (or your GitHub username) |
| `GITHUB_REPO` | `digital-renaissance-kdp` |

Activate the workflow. The webhook URL will appear in the Webhook node. Copy it.

### 6. Test the full chain (1 minute)

```bash
curl -X POST https://mcgeezer81.app.n8n.cloud/webhook/kdp-produce \
  -H "Content-Type: application/json" \
  -d '{"book_slug": "cozy_cottagecore_bold_easy"}'
```

Expected response:
```json
{
  "ok": true,
  "book_slug": "cozy_cottagecore_bold_easy",
  "message": "Pipeline queued. Check GitHub Actions for live status.",
  "actions_url": "https://github.com/mcgeezer81/digital-renaissance-kdp/actions",
  "supabase_book_url": "https://supabase.com/dashboard/project/ohcclvcjdbftlnyrrzvt/editor?schema=public&table=dr_kdp_books",
  "queued_at": "2026-05-17T..."
}
```

Then watch GitHub Actions for the run that just kicked off.

## Triggering a book run

Three ways to start a pipeline run, depending on where you are:

### From anywhere with curl (or Shortcuts on iPhone)
```bash
curl -X POST https://mcgeezer81.app.n8n.cloud/webhook/kdp-produce \
  -H "Content-Type: application/json" \
  -d '{"book_slug": "cozy_cottagecore_bold_easy"}'
```

### From GitHub UI
Actions -> Produce KDP Book -> Run workflow.

### From your local machine (no webhook needed)
```bash
cd kdp-pipeline
source .venv/bin/activate
python main.py
```

## Adding book 2 in the series

Two steps after book 1 ships:

1. **Insert the new book row** in Supabase:
```sql
insert into public.dr_kdp_books (slug, series, volume, title, subtitle)
values (
  'cottagecore_autumn_bold_easy',
  'DR Cozy Aesthetic Coloring Series',
  2,
  'Cottagecore Autumn',
  'Bold & Easy Coloring Book for Adults and Teens, 40 Cozy Autumn Designs of Pumpkins, Mushrooms, and Falling Leaves'
);
```

2. **Update `config.py`** with the new slug, pillars, and prompts. Update `cover.py` `COVER_PROMPT`. Update `listing.py` `LISTING` dict. Commit and push. Trigger via webhook or GitHub UI.

## What you can monitor in Supabase

Quick query to see how each book is doing once a few are live:

```sql
select slug, title, status, total_units, last_30d_royalty
from public.dr_kdp_portfolio
order by last_30d_royalty desc;
```

To see all pipeline runs for cost tracking:

```sql
select
  b.slug,
  r.stage,
  r.status,
  r.duration_seconds,
  r.cost_usd,
  r.provider,
  r.created_at
from public.dr_kdp_pipeline_runs r
join public.dr_kdp_books b on r.book_id = b.id
order by r.created_at desc
limit 50;
```

## Honest limits

- **n8n cloud cannot run the pipeline directly.** The pipeline needs Python with PIL and ReportLab. n8n cloud is for triggering and orchestration only. GitHub Actions hosts the actual run.
- **First run on a fresh fork will fail without secrets.** Add the 4 secrets before running.
- **Replicate has a cold start.** Flux Schnell on free tier can take 30 seconds for the first request, then sub-3-second responses.
- **KDP upload itself stays manual.** No public API exists. About 5 minutes per book once the PDFs are in hand.
- **The seeded `cozy_cottagecore_bold_easy` row already exists in Supabase.** If you want a fully clean test, delete it first: `delete from public.dr_kdp_books where slug = 'cozy_cottagecore_bold_easy';`
