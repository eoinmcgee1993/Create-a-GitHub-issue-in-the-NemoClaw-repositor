"""
KDP listing copy generator.
Produces a JSON file with everything needed to fill the KDP upload form:
  - title and subtitle
  - 7 backend keywords (each under 50 chars)
  - 2 category recommendations
  - book description (A+ ready)
  - bullet points
  - author bio

Usage:
    python listing.py
"""
import json
from pathlib import Path

from config import BOOK, ROOT


LISTING = {
    "asin_status": "pending_upload",
    "title": BOOK["title"],
    "subtitle": BOOK["subtitle"],
    "series_name": BOOK["series"],
    "series_number": BOOK["volume"],
    "author": BOOK["author"],
    "imprint": BOOK["imprint"],
    "language": "English",
    "list_price_usd": BOOK["list_price_usd"],
    "trim_size": BOOK["trim"],
    "interior_type": "Black & white interior with white paper",
    "paperback_isbn": "Free KDP ISBN",
    "categories": [
        "Crafts, Hobbies & Home > Crafts & Hobbies > Coloring Books for Grown-Ups > Nature & Animals",
        "Crafts, Hobbies & Home > Crafts & Hobbies > Coloring Books for Grown-Ups > Flowers & Botanicals",
    ],
    "backend_keywords": [
        "cottagecore coloring book for adults women",
        "bold and easy coloring book for adults",
        "mushroom coloring book bold easy",
        "cozy coloring book for stress relief",
        "woodland coloring book adults mindfulness",
        "cottage core gift for her teen women",
        "simple coloring book for beginners seniors",
    ],
    "description_html": (
        "<h2>Step into the cozy cottagecore world.</h2>"
        "<p>If you have ever wished for a slower, softer kind of evening, this is the coloring book for you. "
        "<strong>Cozy Cottagecore</strong> is a bold and easy coloring book with 40 charming designs of "
        "thatched cottages, woodland creatures, friendly mushrooms, and wildflower gardens, all drawn with "
        "thick, forgiving outlines so you can relax instead of squinting.</p>"
        "<h3>Inside this book you will find:</h3>"
        "<ul>"
        "<li><strong>40 unique cottagecore designs</strong> across 4 themes: cottages and interiors, "
        "woodland creatures, mushrooms and forest floor, wildflowers and kitchen garden</li>"
        "<li><strong>Bold and easy line art</strong>, thick clean outlines that work beautifully with markers, "
        "pencils, gel pens, or crayons</li>"
        "<li><strong>Single sided pages</strong> so your markers will not bleed through to the next design</li>"
        "<li><strong>Large 8.5 by 11 inch format</strong>, plenty of room to color</li>"
        "<li><strong>Beginner and senior friendly</strong>, simple shapes for anyone who finds detailed adult "
        "coloring books overwhelming</li>"
        "</ul>"
        "<h3>Perfect for:</h3>"
        "<ul>"
        "<li>Cozy evenings with a cup of tea and a candle</li>"
        "<li>Stress relief and mindfulness practice</li>"
        "<li>Gifts for cottagecore lovers, mushroom collectors, and quiet souls</li>"
        "<li>Teens and adults who love kawaii and cute aesthetic illustrations</li>"
        "<li>Anyone who wants to slow down and color something charming</li>"
        "</ul>"
        "<p>Grab your colors, find your softest blanket, and step into the cottagecore world. "
        "Volume 1 in the <em>Cozy Aesthetic Coloring Series</em>, with more seasonal volumes coming throughout the year.</p>"
    ),
    "bullets": [
        "40 BOLD AND EASY COTTAGECORE DESIGNS, cottages, woodland creatures, mushrooms, and wildflowers, "
        "all drawn with thick outlines and large open areas, perfect for beginners, seniors, and casual colorists",
        "SINGLE SIDED PAGES on bright white paper so markers, gel pens, and watercolor pencils will not bleed "
        "through to the next design",
        "LARGE 8.5 BY 11 INCH FORMAT gives you plenty of room to color, ideal for relaxing evenings and "
        "mindfulness practice",
        "A CALMING ESCAPE INTO THE COTTAGECORE AESTHETIC, every page features cozy, charming, kawaii style "
        "scenes inspired by countryside life",
        "VOLUME 1 OF THE COZY AESTHETIC COLORING SERIES, a thoughtful gift for cottagecore lovers, "
        "mushroom enthusiasts, and anyone who needs a quiet hour to themselves",
    ],
    "author_bio": (
        "Digital Renaissance Press publishes calming bold and easy coloring books designed for adults, "
        "teens, and anyone who finds detailed adult coloring overwhelming. Each title in the Cozy Aesthetic "
        "series focuses on thick, forgiving outlines and warm, inviting subject matter to help readers slow down."
    ),
    "ads_starter_keywords": [
        "cottagecore coloring book",
        "bold and easy coloring book",
        "mushroom coloring book",
        "cozy coloring book adults",
        "woodland coloring book",
        "cute coloring book for adults",
        "mindfulness coloring book",
    ],
    "pinterest_pin_ideas": [
        "Pin 1: 6 sample uncolored pages in a 2x3 grid, headline 'Free Cottagecore Coloring Pages'",
        "Pin 2: A colored sample with markers visible, headline 'The Cottagecore Coloring Book You Will Actually Finish'",
        "Pin 3: Hand colored mushroom page on a cozy desk with tea, headline 'Slow Down, Color Something Charming'",
        "Pin 4: Before and after split, line art vs colored, headline 'Bold and Easy, So You Can Just Relax'",
    ],
}


def save():
    path = ROOT / "listing.json"
    path.write_text(json.dumps(LISTING, indent=2))
    return path


if __name__ == "__main__":
    p = save()
    print(f"Wrote {p}")
    print(f"\nTitle: {LISTING['title']}")
    print(f"Subtitle: {LISTING['subtitle']}")
    print(f"\nBackend keywords:")
    for k in LISTING["backend_keywords"]:
        print(f"  ({len(k):2d} chars) {k}")
