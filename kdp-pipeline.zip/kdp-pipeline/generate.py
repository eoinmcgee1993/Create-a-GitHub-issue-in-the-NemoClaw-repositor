"""
Image generation module.
Batches the 40 prompts through Replicate (Flux Schnell or Dev) or OpenAI image API.
Concurrency capped at config.CONCURRENT_REQUESTS, retries on failure.

Usage:
    python generate.py
"""
import asyncio
import base64
import json
import logging
import os
from pathlib import Path
from typing import Optional

import httpx

from config import (
    REPLICATE_API_TOKEN,
    OPENAI_API_KEY,
    IMAGE_PROVIDER,
    IMAGE_SIZE,
    CONCURRENT_REQUESTS,
    RETRY_LIMIT,
    RAW_DIR,
    LOG_DIR,
    ROOT,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "generate.log"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("generate")


# ---------- Replicate (Flux) ----------
REPLICATE_MODELS = {
    "replicate_flux_schnell": "black-forest-labs/flux-schnell",
    "replicate_flux_dev": "black-forest-labs/flux-dev",
}


async def _replicate_run(client: httpx.AsyncClient, prompt: str, model_slug: str) -> bytes:
    """Call Replicate model, poll until complete, return PNG bytes."""
    headers = {
        "Authorization": f"Bearer {REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
        "Prefer": "wait",
    }
    payload = {
        "input": {
            "prompt": prompt,
            "aspect_ratio": "1:1",
            "output_format": "png",
            "output_quality": 100,
            "num_outputs": 1,
        }
    }
    resp = await client.post(
        f"https://api.replicate.com/v1/models/{model_slug}/predictions",
        headers=headers,
        json=payload,
        timeout=120,
    )
    resp.raise_for_status()
    data = resp.json()

    # Poll if still processing
    while data.get("status") in ("starting", "processing"):
        await asyncio.sleep(1.5)
        get_url = data["urls"]["get"]
        poll = await client.get(get_url, headers=headers, timeout=60)
        poll.raise_for_status()
        data = poll.json()

    if data.get("status") != "succeeded":
        raise RuntimeError(f"Replicate failed: {data.get('error') or data.get('status')}")

    output = data["output"]
    image_url = output[0] if isinstance(output, list) else output

    img_resp = await client.get(image_url, timeout=60)
    img_resp.raise_for_status()
    return img_resp.content


# ---------- OpenAI gpt-image-1 ----------
async def _openai_run(client: httpx.AsyncClient, prompt: str) -> bytes:
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "gpt-image-1",
        "prompt": prompt,
        "size": "1024x1024",
        "n": 1,
        "background": "white",
    }
    resp = await client.post(
        "https://api.openai.com/v1/images/generations",
        headers=headers,
        json=payload,
        timeout=180,
    )
    resp.raise_for_status()
    data = resp.json()
    b64 = data["data"][0]["b64_json"]
    return base64.b64decode(b64)


# ---------- Dispatcher ----------
async def _run_one(client: httpx.AsyncClient, prompt_entry: dict, semaphore: asyncio.Semaphore) -> dict:
    async with semaphore:
        out_path = RAW_DIR / prompt_entry["filename"]
        if out_path.exists():
            log.info(f"SKIP existing {out_path.name}")
            prompt_entry["status"] = "skipped"
            return prompt_entry

        for attempt in range(1, RETRY_LIMIT + 1):
            try:
                log.info(f"GEN  [{prompt_entry['index']:02d}/{40}] {prompt_entry['filename']} attempt {attempt}")
                if IMAGE_PROVIDER.startswith("replicate"):
                    model_slug = REPLICATE_MODELS[IMAGE_PROVIDER]
                    png_bytes = await _replicate_run(client, prompt_entry["prompt"], model_slug)
                elif IMAGE_PROVIDER == "openai_gpt_image":
                    png_bytes = await _openai_run(client, prompt_entry["prompt"])
                else:
                    raise ValueError(f"Unknown IMAGE_PROVIDER {IMAGE_PROVIDER}")

                out_path.write_bytes(png_bytes)
                prompt_entry["status"] = "ok"
                log.info(f"OK   {prompt_entry['filename']}")
                return prompt_entry
            except Exception as exc:
                log.warning(f"FAIL {prompt_entry['filename']} attempt {attempt}: {exc}")
                if attempt == RETRY_LIMIT:
                    prompt_entry["status"] = f"error: {exc}"
                    return prompt_entry
                await asyncio.sleep(2 * attempt)
    return prompt_entry


async def run_all(manifest_path: Optional[Path] = None) -> Path:
    manifest_path = manifest_path or (ROOT / "prompts.json")
    manifest = json.loads(manifest_path.read_text())

    if IMAGE_PROVIDER.startswith("replicate") and not REPLICATE_API_TOKEN:
        raise RuntimeError("REPLICATE_API_TOKEN not set. Add it to .env")
    if IMAGE_PROVIDER == "openai_gpt_image" and not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY not set. Add it to .env")

    semaphore = asyncio.Semaphore(CONCURRENT_REQUESTS)
    async with httpx.AsyncClient() as client:
        tasks = [_run_one(client, p, semaphore) for p in manifest["prompts"]]
        results = await asyncio.gather(*tasks)

    manifest["prompts"] = results
    out_path = ROOT / "prompts.json"
    out_path.write_text(json.dumps(manifest, indent=2))

    ok = sum(1 for r in results if r["status"] in ("ok", "skipped"))
    log.info(f"DONE {ok}/{len(results)} succeeded")
    return out_path


if __name__ == "__main__":
    asyncio.run(run_all())
