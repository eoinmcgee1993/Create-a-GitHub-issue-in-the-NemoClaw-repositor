"""
Image cleaning module.
For each raw generated image, produce a KDP ready page asset:
  - convert to grayscale
  - apply threshold to force pure black on pure white (no gray artifacts)
  - upscale to 300 DPI sized for 8.5x11 trim, centered inside the safe area
  - save as 1-bit PNG ready to embed in the interior PDF

Usage:
    python clean.py
"""
import json
import logging
from pathlib import Path

from PIL import Image, ImageOps, ImageFilter

from config import (
    RAW_DIR,
    CLEAN_DIR,
    LOG_DIR,
    TRIM_W_PX,
    TRIM_H_PX,
    SAFE_MARGIN_PX,
    DPI,
    ROOT,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "clean.log"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("clean")


THRESHOLD = 200  # 0 to 255, anything brighter than this becomes white


def clean_one(raw_path: Path, out_path: Path) -> bool:
    """Process one raw image into a KDP ready 1-bit page asset."""
    try:
        img = Image.open(raw_path).convert("RGB")

        # Step 1: convert to grayscale
        gray = img.convert("L")

        # Step 2: slight sharpen to recover line crispness after upscale
        gray = gray.filter(ImageFilter.SHARPEN)

        # Step 3: hard threshold to pure B&W (no gray pixels in print)
        bw = gray.point(lambda p: 255 if p > THRESHOLD else 0)

        # Step 4: invert check, if image is mostly black (failure mode), reject
        hist = bw.histogram()
        black_pixels = hist[0]
        white_pixels = hist[255]
        total = black_pixels + white_pixels
        if total == 0 or (black_pixels / total) > 0.5:
            log.warning(f"REJECT {raw_path.name}: too dark, likely solid fill (regenerate)")
            return False

        # Step 5: resize to fit inside the safe area, preserving aspect ratio
        safe_w = TRIM_W_PX - 2 * SAFE_MARGIN_PX
        safe_h = TRIM_H_PX - 2 * SAFE_MARGIN_PX
        bw.thumbnail((safe_w, safe_h), Image.LANCZOS)

        # Step 6: re-threshold after resize (LANCZOS reintroduces gray)
        bw = bw.point(lambda p: 255 if p > THRESHOLD else 0)

        # Step 7: paste onto white 8.5x11 canvas, centered
        page = Image.new("L", (TRIM_W_PX, TRIM_H_PX), 255)
        offset_x = (TRIM_W_PX - bw.width) // 2
        offset_y = (TRIM_H_PX - bw.height) // 2
        page.paste(bw, (offset_x, offset_y))

        # Step 8: convert to 1-bit mode for smallest possible file, set DPI
        page_1bit = page.convert("1")
        page_1bit.save(out_path, dpi=(DPI, DPI), optimize=True)
        log.info(f"OK   {out_path.name}")
        return True
    except Exception as exc:
        log.error(f"FAIL {raw_path.name}: {exc}")
        return False


def run_all() -> dict:
    manifest_path = ROOT / "prompts.json"
    manifest = json.loads(manifest_path.read_text())

    cleaned = 0
    rejected = []
    for entry in manifest["prompts"]:
        raw = RAW_DIR / entry["filename"]
        if not raw.exists():
            log.warning(f"SKIP {entry['filename']}: raw file missing")
            rejected.append(entry["filename"])
            continue
        out = CLEAN_DIR / entry["filename"]
        if clean_one(raw, out):
            cleaned += 1
            entry["clean_status"] = "ok"
        else:
            rejected.append(entry["filename"])
            entry["clean_status"] = "rejected"

    manifest_path.write_text(json.dumps(manifest, indent=2))
    log.info(f"DONE {cleaned}/{len(manifest['prompts'])} cleaned, {len(rejected)} rejected")
    return {"cleaned": cleaned, "rejected": rejected}


if __name__ == "__main__":
    result = run_all()
    if result["rejected"]:
        print("\nRejected files (re-run generate.py for these):")
        for r in result["rejected"]:
            print(f"  - {r}")
